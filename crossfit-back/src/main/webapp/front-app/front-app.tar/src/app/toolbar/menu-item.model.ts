export class MenuItem{

    action: Function;
    icon: string;
    text: string;
  }