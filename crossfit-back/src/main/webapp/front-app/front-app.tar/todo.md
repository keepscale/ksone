* [ ] Planning des wods (Les wod "personnalisé" ne sont disponibles qu'un seul jour, jamais les mêmes)
* [ ] Le wod du mois
* [ ] Importer les wods de référence, qualif, girls, heros
* [ ] Améliorer le profil (photo, poids, taille, age, sex, pseudo)
* [ ] Confidentialité: Autoriser le partage de mon score
* [ ] Saisi de wod => Que les coachs
* [ ] Menu utilisateur (profil, activité, PR) / Administrateur (Planning des wods)