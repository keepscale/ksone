/**
 * Service layer beans.
 */
package org.crossfit.app.service;
