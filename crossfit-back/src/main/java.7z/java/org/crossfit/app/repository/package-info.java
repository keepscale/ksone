/**
 * Spring Data JPA repositories.
 */
package org.crossfit.app.repository;
