package org.crossfit.app.i18n.domain.enumeration;

public enum LangKey {
	
	fr_FR, en_EN;
}
