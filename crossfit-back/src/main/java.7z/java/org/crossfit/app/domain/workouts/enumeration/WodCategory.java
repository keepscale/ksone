package org.crossfit.app.domain.workouts.enumeration;

public enum WodCategory {
	BENCHMARK, QUALIFIER, GIRL, HEROES, CUSTOM;
}
