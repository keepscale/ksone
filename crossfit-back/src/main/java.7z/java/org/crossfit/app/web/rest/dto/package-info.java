/**
 * Data Transfer Objects used by Spring MVC REST controllers.
 */
package org.crossfit.app.web.rest.dto;
