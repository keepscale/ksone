package org.crossfit.app.domain.enumeration;

/**
 * The BookingStatus enumeration.
 */
public enum BookingStatus {
    VALIDATED
}
