package org.crossfit.app.domain.workouts.result;

public enum ResultCategory {
	RX, SCALED
}
