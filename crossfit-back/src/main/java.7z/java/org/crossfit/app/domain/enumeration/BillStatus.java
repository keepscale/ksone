package org.crossfit.app.domain.enumeration;

/**
 * The BillStatus enumeration.
 */
public enum BillStatus {
    VALIDE, ANNULE, DRAFT
}
