package org.crossfit.app.domain.enumeration;

public enum Title {
	MS, MR
}
