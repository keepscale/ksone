/**
 * Spring Security configuration.
 */
package org.crossfit.app.security;
