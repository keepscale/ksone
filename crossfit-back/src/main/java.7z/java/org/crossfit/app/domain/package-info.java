/**
 * JPA domain objects.
 */
package org.crossfit.app.domain;
