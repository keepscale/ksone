package org.crossfit.app.domain.enumeration;

public enum CardEventStatus {
	NO_MEMBER, NO_BOOKING, OK;
}
