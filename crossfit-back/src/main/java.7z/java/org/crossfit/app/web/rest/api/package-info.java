/**
 * Spring MVC REST controllers.
 */
package org.crossfit.app.web.rest.api;
