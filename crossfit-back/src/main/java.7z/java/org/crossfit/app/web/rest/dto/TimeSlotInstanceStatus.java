package org.crossfit.app.web.rest.dto;

/**
 * The TimeSlotStatus enumeration.
 */
public enum TimeSlotInstanceStatus {
    FREE, BOOKED, NOT_AVAILABLE, FULL
}
