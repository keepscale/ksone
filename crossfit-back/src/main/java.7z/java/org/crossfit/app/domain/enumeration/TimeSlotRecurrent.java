package org.crossfit.app.domain.enumeration;

public enum TimeSlotRecurrent {
	DAY_OF_WEEK, DATE;
}
