package org.crossfit.app.domain.workouts.enumeration;

public enum MovementType {
	SQUAT, PRESS, LIFT, OLYMPIC_LIFTING, GYMNASTIC, OTHER;
}
