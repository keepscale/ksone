package org.crossfit.app.i18n.domain;

public interface I18nGroupNameKey {
	public String getI18nGroupName();
}
