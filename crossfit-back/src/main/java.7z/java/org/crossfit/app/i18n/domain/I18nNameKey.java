package org.crossfit.app.i18n.domain;

public interface I18nNameKey {
	public String getI18nName();
}
