package org.crossfit.app.domain.enumeration;

public enum BookingEventType {
	CREATED, DELETED;
}
