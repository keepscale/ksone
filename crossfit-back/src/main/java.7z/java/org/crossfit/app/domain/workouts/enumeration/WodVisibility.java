package org.crossfit.app.domain.workouts.enumeration;

public enum WodVisibility {
	PUBLIC, PRIVATE
}
